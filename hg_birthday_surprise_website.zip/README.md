# Birthday Surprise Website ♡

This is a ready-to-publish static birthday website.

## Publish it
The easiest free option is GitHub Pages:
1. Create a GitHub repository.
2. Upload everything in this folder.
3. Make sure `index.html` is at the top level.
4. Enable GitHub Pages from Settings → Pages.
5. Open the published site.
6. The website's final "secret QR" button automatically generates a QR code for the live URL.

## Personalize
Open `index.html` and change:
- the birthday date text
- the letter
- the surprise messages
- the title
- the song link if you want a different version

Replace `assets/her-1.jpeg` and `assets/her-2.jpeg` with any other photos, keeping the same filenames.

## Music note
Browsers generally block websites from autoplaying audio with sound. The music button therefore opens the song instead. If you have a licensed/local audio file, the page can be modified to play it after the visitor taps the button.
